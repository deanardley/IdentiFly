import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  await Supabase.initialize(
      url: 'https://jwqylkdaczmorisysvnl.supabase.co',
      anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp3cXlsa2RhY3ptb3Jpc3lzdm5sIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjI1NzEzMTcsImV4cCI6MjA3ODE0NzMxN30.V6yxVDCuwKQ2wNs0mBx0qtqAbAj1mHcOXffZOz7-Uk8',
  );

  runApp(MaterialApp(
    home: UploadImg(),
  ));
}

class UploadImg extends StatefulWidget {
  const UploadImg({super.key});

  @override
  State<UploadImg> createState() => _UploadImgState();
}

class _UploadImgState extends State<UploadImg> {

  File? selectedFile;
  String fileName = "No file currently";

  FirebaseStorage firebaseStorage = FirebaseStorage.instance;
  FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;
  FirebaseAuth firebaseAuth = FirebaseAuth.instance;

  Future<void> _uploadImg() async{
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['jpg', 'jpeg']
    );

    if(result != null && result.files.single.name != null){
      setState(() {
        selectedFile = File(result.files.single.path!);
        fileName = result.files.single.name;
      });
    }
  }

  Future<void> _storeImg() async{
    if(selectedFile == null){
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Please select an image."))
      );
    }

    try{

      final supabase = Supabase.instance.client;

      final imgBytes = await selectedFile!.readAsBytes();
      final imgPath = "location_images/${DateTime.now().millisecondsSinceEpoch}_$fileName";

      await supabase.storage.from('location_images').uploadBinary(
        imgPath,
        imgBytes,
        fileOptions: const FileOptions(contentType: 'image/jpeg'),
      );

      final publicUrl = supabase.storage.from("location_images").getPublicUrl(imgPath);

      await firebaseFirestore.collection('images').doc().set({
        "img_url": publicUrl,
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Image Upload Successful"))
      );

    }catch (e){
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e"))
      );
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green
                ),
                onPressed: (){
                    _uploadImg();
                },
                child: Text("Upload Image", style: TextStyle(color: Colors.white)),
              ),

              SizedBox(height: 10,),

              ElevatedButton(
                onPressed: (){
                  _storeImg();
                },
                child: Text("Store Image", style: TextStyle(color: Colors.white)
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
