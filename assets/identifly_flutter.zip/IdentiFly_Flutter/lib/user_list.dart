import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:path/path.dart' as p;
import 'package:identifly_flutter/pdf_viewer.dart';
import 'package:identifly_flutter/update_user.dart';
import 'package:identifly_flutter/login.dart';
import 'package:identifly_flutter/pending_request.dart';
import 'package:identifly_flutter/admin_dashboard.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "IdentiFly",
      home: UserList(),
    );
  }
}

class UserList extends StatefulWidget {
  const UserList({super.key});

  @override
  State<UserList> createState() => _UserListState();
}



class _UserListState extends State<UserList> {
  String searchName = "";
  final TextEditingController searchController = TextEditingController();

  Future<void> showInformation(Map<String, dynamic> userData) async{
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),

        contentPadding: EdgeInsets.all(20),

        title: Text(
          "User Information",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text("Username:", style: TextStyle(fontSize: 15),),
            Text("${userData['username'] ?? 'N/A'}", style: TextStyle(fontSize: 15),),

            SizedBox(height: 10,),

            Text("Email:", style: TextStyle(fontSize: 15),),
            Text("${userData['email'] ?? 'N/A'}", style: TextStyle(fontSize: 15),),

            SizedBox(height: 10,),

            Text("Gender:", style: TextStyle(fontSize: 15),),
            Text("${userData['gender'] ?? 'N/A'}", style: TextStyle(fontSize: 15),),

            SizedBox(height: 10,),

            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              onPressed: () {
                final url = userData['cert_url'];

                if(url != null && url.isNotEmpty){
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => PdfViewer(url: url),
                    ),
                  );
                }else{
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text("No document available")),
                  );
                }
              },
              child: Text("View Certificate", style: TextStyle(fontSize: 15, color: Colors.white),),
            ),

            Align(
              alignment: Alignment.center,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.grey[50],
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    )
                ),
                onPressed: () => Navigator.pop(context),
                child: Text("Close", style: TextStyle(fontSize: 15, color: Colors.black),),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final Stream<QuerySnapshot> approvedUsers = FirebaseFirestore.instance
        .collection('users').where('status', isEqualTo: 'Approved').where('role', isEqualTo: 'User').snapshots();

    return Scaffold(
      appBar: AppBar(
        title: Text('Users', style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.green[800],
        iconTheme: IconThemeData(color: Colors.white),
      ),

      drawer: Drawer(
        child: ListView(
          children: <Widget>[
            ListTile(
                title: Text('Dashboard'),
                leading: Icon(Icons.bar_chart),
                onTap: (){
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (BuildContext context) => AdminDashboard()),
                  );
                }
            ),
            ListTile(
              title: Text('Pending Requests'),
              leading: Icon(Icons.pending_actions),
              onTap: (){
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (BuildContext context) => PendingRequest())
                );
              }

            ),
            ListTile(
              title: Text('Users List'),
              leading: Icon(Icons.supervised_user_circle),
            ),

            ListTile(
              title: Text('Log Out'),
              leading: Icon(Icons.logout),
              onTap: (){
                Navigator.pop(context);
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (BuildContext context) => Login()),
                );
              },
            ),
          ],
        ),
      ),

      body: StreamBuilder(
        stream: approvedUsers,
        builder: (context, snapshot){
          if(!snapshot.hasData || snapshot.data!.docs.isEmpty){
            return Center(
              child: Text(
                "No users.",
                style: TextStyle(fontSize: 16),
              ),
            );
          }

          final allApprovedUsers = snapshot.data!.docs;

          final filteredUsers = allApprovedUsers.where((user){
            final username = user['username'].toString().toLowerCase();
            return username.contains(searchName.toLowerCase());
          }).toList();

          return Column(
            children: [
              Card(
              color: Colors.green[100],
                margin: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                elevation: 8,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Padding(
                  padding: EdgeInsets.all(15),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextField(
                        controller: searchController,
                        decoration: InputDecoration(
                          hintText: "Search name",
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                        ),
                      ),
                      SizedBox(height: 10,),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green[800],
                        ),
                        onPressed: (){
                          setState(() {
                            searchName = searchController.text.trim();
                          });
                        },
                        child: Text(
                          "Search",
                          style: TextStyle(fontSize: 15, color: Colors.white),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              Expanded(
                child: ListView.builder(
                    itemCount: filteredUsers.length,
                    itemBuilder: (context, index){
                      var user = filteredUsers[index];
                      return Card(
                        margin: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                        elevation: 8,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15)
                        ),
                        child: Padding(
                          padding: EdgeInsets.all(15),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text(
                                user['username'],
                                style: TextStyle(fontSize: 25,),
                              ),

                              ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.green[800],
                                ),
                                onPressed: (){
                                  showInformation({
                                    'username': user['username'],
                                    'email': user['email'],
                                    'gender': user['gender'],
                                    'cert_url': user['cert_url'],
                                  });
                                },
                                child: Text(
                                  "View Information",
                                  style: TextStyle(fontSize: 15, color: Colors.white),
                                ),
                              ),

                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  ElevatedButton(
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.red[800],
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(30),
                                      ),
                                    ),
                                    onPressed: () async{
                                      await FirebaseFirestore.instance.collection('users').doc(user.id).delete();
                                    },
                                    child: Text(
                                      "Delete",
                                      style: TextStyle(fontSize: 15, color: Colors.white),
                                    ),
                                  ),

                                  SizedBox(width: 20,),

                                  ElevatedButton(
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.green[800],
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(30),
                                      ),
                                    ),
                                    onPressed: (){
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (_) => UpdateUser(userId: user.id, userData: user.data() as Map<String, dynamic>),
                                        ),
                                      );
                                    },
                                    child: Text(
                                      "Update",
                                      style: TextStyle(fontSize: 15, color: Colors.white),
                                    ),
                                  ),
                                ],
                              )
                            ],
                          ),
                        ),
                      );
                    }
                ),
              ),
            ],
          );
        },
      ),

    );
  }
}
