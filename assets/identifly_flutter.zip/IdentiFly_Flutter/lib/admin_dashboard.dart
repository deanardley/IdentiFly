import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:identifly_flutter/login.dart';
import 'package:identifly_flutter/pending_request.dart';
import 'package:identifly_flutter/user_list.dart';
import 'package:pie_chart/pie_chart.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "IdentiFly",
      home: AdminDashboard(),
    );
  }
}

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {

  int approvedCount = 0, pendingCount = 0, rejectedCount = 0, maleCount = 0, femaleCount = 0;

  @override
  void initState(){
    super.initState();
    fetchUsersCount();
    countGender();
  }

  Future<void> countGender() async{
    final firestore = FirebaseFirestore.instance;
    try{
      final maleSnapshot = await firestore.collection('users')
          .where('gender', isEqualTo: 'Male')
          .where('status', isEqualTo: 'Approved')
          .where('role', isEqualTo: 'User').get();

      final femaleSnapshot = await firestore.collection('users')
          .where('gender', isEqualTo: 'Female')
          .where('status', isEqualTo: 'Approved')
          .where('role', isEqualTo: 'User').get();

      setState(() {
        maleCount = maleSnapshot.size;
        femaleCount = femaleSnapshot.size;
      });
    }catch(e){
      print("Error fetching gender counts: ${e}");
    }
  }

  Future<void> fetchUsersCount() async{
    final firestore = FirebaseFirestore.instance;
    try{
      final approvedSnapshot = await firestore.collection('users')
          .where('status', isEqualTo: 'Approved')
          .get();

      final pendingSnapshot = await firestore.collection('users')
          .where('status', isEqualTo: 'Pending')
          .get();

      final rejectedSnapshot = await firestore.collection('users')
          .where('status', isEqualTo: 'Rejected')
          .get();

      setState(() {
        approvedCount = approvedSnapshot.size;
        pendingCount = pendingSnapshot.size;
        rejectedCount = rejectedSnapshot.size;
      });
    }catch(e){
      print("Error fetching user counts: $e");
    }
  }

  @override
  Widget build(BuildContext context) {

    //Pie Chart Data
    Map<String, double> dataMap = {
      "Male": maleCount.toDouble(),
      "Female": femaleCount.toDouble()
    };

    //Pie Chart Colors
    List<Color> colorList = [
      Colors.lightBlue,
      Colors.pinkAccent,
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text('Admin Dashboard', style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.green[800],
        iconTheme: IconThemeData(color: Colors.white),
      ),

      drawer: Drawer(
        child: ListView(
          children: <Widget>[
            ListTile(
              title: Text('Dashboard'),
              leading: Icon(Icons.bar_chart),
            ),
            ListTile(
              title: Text('Pending Requests'),
              leading: Icon(Icons.pending_actions),
              onTap: (){
                Navigator.pop(context);
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (BuildContext context) => PendingRequest()),
                );
              },
            ),
            ListTile(
              title: Text('Users List'),
              leading: Icon(Icons.supervised_user_circle),
              onTap: (){
                Navigator.pop(context);
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (BuildContext context) => UserList()),
                );
              },
            ),

            ListTile(
              title: Text('Log Out'),
              leading: Icon(Icons.logout),
              onTap: (){
                Navigator.pop(context);
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (BuildContext context) => Login()),
                );
              },
            ),
          ],
        ),
      ),

      body: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 25),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SizedBox(height: 20,),

              Card(
                color: Colors.green[100],
                elevation: 5,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Padding(
                  padding: EdgeInsets.all(18),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Approved Users:",
                        style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        approvedCount.toString(),
                        style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(width: 10),
              Row(
                children: [
                  Expanded(
                    child: Card(
                      color: Colors.red[100],
                      elevation: 5,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: Padding(
                        padding: EdgeInsets.all(18),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Rejected Users:",
                              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                            ),
                            Text(
                              rejectedCount.toString(),
                              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                  SizedBox(width: 10),

                  Expanded(
                    child: Card(
                      color: Colors.orange[100],
                      elevation: 5,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: Padding(
                        padding: EdgeInsets.all(18),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Pending Users:",
                              style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                            ),
                            Text(
                              pendingCount.toString(),
                              style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                ],
              ),

              SizedBox(height: 20,),

              Center(
                child: Column(
                  children: [
                    Text(
                      "Gender Distribution",
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),

                    SizedBox(height: 10,),

                    PieChart(
                      dataMap: dataMap,
                      colorList: colorList,
                      chartRadius: 250,
                      ringStrokeWidth: 20,
                      animationDuration: const Duration(milliseconds: 3000),

                      chartValuesOptions: const ChartValuesOptions(
                        showChartValues: true,
                        showChartValuesOutside: true,
                        showChartValueBackground: false,
                        showChartValuesInPercentage: false
                      ),

                      legendOptions: const LegendOptions(
                        showLegends: true,
                        legendShape: BoxShape.rectangle,
                        legendTextStyle: TextStyle(fontSize: 14),
                        legendPosition: LegendPosition.bottom,
                        showLegendsInRow: true
                      ),
                    ),
                  ],
                ),
              ),

            ],
          ),
      ),
    );
  }
}
