import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:identifly_flutter/admin_dashboard.dart';
import 'package:identifly_flutter/user_list.dart';
import 'package:identifly_flutter/login.dart';
import 'package:identifly_flutter/pdf_viewer.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:firebase_core/firebase_core.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Identifly",
      home: PendingRequest(),
    );
  }
}


class PendingRequest extends StatefulWidget {
  const PendingRequest({super.key});

  @override
  State<PendingRequest> createState() => _PendingRequestState();
}

class _PendingRequestState extends State<PendingRequest> {
  @override
  Widget build(BuildContext context) {
    final Stream<QuerySnapshot> pendingUsers = FirebaseFirestore.instance
        .collection('users')
        .where('status', isEqualTo: 'Pending')
        .snapshots();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green[900],
        title: Text("Pending Requests", style: TextStyle(color: Colors.white),),
        iconTheme: IconThemeData(color: Colors.white),
      ),

      drawer: Drawer(
        child: ListView(
          children: <Widget>[
            ListTile(
              title: Text('Dashboard'),
              leading: Icon(Icons.bar_chart),
              onTap: (){
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (BuildContext context) => AdminDashboard()),
                );
              }
            ),
            ListTile(
              title: Text('Pending Requests'),
              leading: Icon(Icons.pending_actions),
            ),
            ListTile(
              title: Text('Users List'),
              leading: Icon(Icons.supervised_user_circle),
              onTap: (){
                Navigator.pop(context);
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (BuildContext context) => UserList()),
                );
              },
            ),

            ListTile(
              title: Text('Log Out'),
              leading: Icon(Icons.logout),
              onTap: (){
                Navigator.pop(context);
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (BuildContext context) => Login()),
                );
              },
            ),
          ],
        ),
      ),

      body: StreamBuilder<QuerySnapshot>(
        stream: pendingUsers,
        builder: (context, snapshot){
          if(!snapshot.hasData || snapshot.data!.docs.isEmpty){
            return Center(
              child: Text(
                "No pending requests.",
                style: TextStyle(fontSize: 16),
              ),
            );
          }

          final users = snapshot.data!.docs;

          return ListView.builder(
              itemCount: users.length,
              itemBuilder: (context, index){
                var user = users[index];
                return Card(
                  margin: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                  elevation: 8,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(15),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Username: ${user['username']}"),
                        Text("Email: ${user['email']}"),
                        Text("Gender: ${user['gender']}"),

                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green[800],
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                          ),
                          onPressed: () {
                            final url = user['cert_url'];

                            if(url != null && url.isNotEmpty){
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => PdfViewer(url: url),
                                ),
                              );
                            }else{
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text("No document available")),
                              );
                            }
                          },
                          child: Text(
                            "View Certificate",
                            style: TextStyle(fontSize: 15, color: Colors.white),
                          ),
                        ),

                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.red[800],
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30),
                                ),
                              ),
                              onPressed: () async{
                                await FirebaseFirestore.instance.collection('users').doc(user.id).update({'status': 'Rejected'});
                              },
                              child: Text(
                                "Reject",
                                style: TextStyle(fontSize: 15, color: Colors.white),
                              ),
                            ),

                            SizedBox(width: 10,),

                            ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.green[800],
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30),
                                ),
                              ),
                              onPressed: () async{
                                await FirebaseFirestore.instance.collection('users').doc(user.id).update({'status': 'Approved'});
                              },
                              child: Text(
                                "Approve",
                                style: TextStyle(fontSize: 15, color: Colors.white),
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                );
              }
          );
        },
      ),
    );
  }
}
