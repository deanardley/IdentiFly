import 'dart:math';

import 'package:flutter/material.dart';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:tflite_flutter/tflite_flutter.dart';
import 'package:path/path.dart' as p;
import 'package:image/image.dart' as img;

void main(){
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MaterialApp(
      home: Classify(),
  ));
}


class Classify extends StatefulWidget {
  const Classify({super.key});

  @override
  State<Classify> createState() => _ClassifyState();
}

class _ClassifyState extends State<Classify> {
  final imagePicker = ImagePicker();
  Interpreter? interpreter;
  String? result;
  File? imageFile;


  Future<void> loadModel() async {
    try {
      // Automatically looks in your "assets" folder
      interpreter = await Interpreter.fromAsset("assets/fly_species_classifier_cnn.tflite");
      print('Model loaded from assets');
    } catch (e) {
      print('Failed to load model: $e');
    }
  }

  Future<void> _pickImage() async{
    final pickedImage = await imagePicker.pickImage(source: ImageSource.gallery);
    if(pickedImage != null){
      setState(() {
        imageFile = File(pickedImage.path);
        result = null;
      });
    }
  }

  Future<void> _classifyImage() async{
    if(imageFile == null || interpreter == null){
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Please select an image.")),
      );
      return;
    }

    final bytes = await imageFile!.readAsBytes();
    img.Image? imageInput = img.decodeImage(bytes);

    if(imageInput == null){
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Failed to load image")),
      );
      return;
    }

    imageInput = img.copyResize(imageInput, width: 224, height: 224);
    var input = List.generate(1, (i) => List.generate(224, (y) => List.generate(224, (x){
      final pixel = imageInput!.getPixel(x, y);
      return[
        img.getRed(pixel) / 255.0,
        img.getGreen(pixel) / 255.0,
        img.getBlue(pixel) / 255.0
      ];
    })));
    var output = List.filled(3, 0.0).reshape([1, 3]);

    interpreter!.run(input, output);

    int maxIndex = 0;
    double maxConfidence = output[0][0];

    for(int i = 1; i < output[0].length; i++){
      if(output[0][i] > maxConfidence){
        maxConfidence = output[0][i];
        maxIndex = i;
      }
    }
    final speciesName = ["Chrysomya megacephala", "Chrysomya rufifacies", "Hemipyrellia ligurriens"];
    final predictedSpecies = speciesName[maxIndex];
    setState(() {
      result = predictedSpecies;
    });

    _showDialog(predictedSpecies, maxConfidence);
  }

  Future<void> _showDialog(String species, double maxConfidence) async{
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadiusGeometry.circular(20),
        ),

        contentPadding: EdgeInsets.all(20),

        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if(imageFile != null) Image.file(imageFile!, height: 224, width: 224,),

            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  species,
                  style: TextStyle(fontSize: 20, fontStyle: FontStyle.italic, color: Colors.green[800]),
                  textAlign: TextAlign.center,
                ),

                Text(
                  "Accuracy: ${(maxConfidence * 100).toStringAsFixed(2)}%",
                  style: TextStyle(fontSize: 16, color: Colors.black),
                  textAlign: TextAlign.center,
                ),

                SizedBox(height: 10,),

                Column(
                  children: [
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green[800],
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadiusGeometry.circular(30),
                        ),
                      ),
                      onPressed: () => Navigator.pop(context),
                      child: Text(
                        "View Information",
                        style: TextStyle(fontSize: 16, color: Colors.white),
                      ),
                    ),

                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadiusGeometry.circular(30)
                        ),
                      ),
                      onPressed: () => Navigator.pop(context),
                      child: Text(
                        "Close",
                        style: TextStyle(fontSize: 16, color: Colors.black),
                      ),
                    ),
                  ],
                ),
              ],
            )


          ],
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    loadModel();
  }

  @override
  void dispose() async{
    super.dispose();
    interpreter?.close();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "Enter an image: ",
                style: TextStyle(fontSize: 20),
              ),

              SizedBox(height: 20),

              Container(
                height: 200,
                width: 200,
                decoration: BoxDecoration(
                    color: Colors.white
                ),
                child: imageFile != null
                    ? Image.file(imageFile!, fit: BoxFit.cover,)
                    : Center(child: Text("No image selected")),
              ),

              SizedBox(height: 20),

              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.grey,
                      ),
                      onPressed: _pickImage,
                      child: Text(
                        "Select Image",
                        style: TextStyle(fontSize: 15),
                      )
                  ),

                  SizedBox(width: 10),

                  ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.grey,
                      ),
                      onPressed: _classifyImage,
                      child: Text(
                        "Predict",
                        style: TextStyle(fontSize: 15),
                      )
                  ),
                ],
              )


            ],
          ),
        ),
      ),
    );
  }
}
